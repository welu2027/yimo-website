Skip to
content
Kaggle

Create
Home

Competitions

Datasets

Models

Benchmarks

Game Arena

Code

Discussions

Learn

More

Your Work


Viewed

Measuring Progress Toward AGI - Cognitive Abilities


New Benchmark Task 792c0


IgnoranceForge


Important submission info: please read before you submit


The Gemma 4 Good Hackathon


Edited

New Benchmark Task 792c0


IgnoranceForge


notebook91a9c96e49


notebook551e1df6fb


Graph2Proof


View Active Events

Search

Kaggle uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.
Learn more
OK, Got it.
Google DeepMind · Featured Hackathon · 10 hours to go

View Writeups
Measuring Progress Toward AGI - Cognitive Abilities
Design high-quality benchmarks that go beyond recall to evaluate how frontier models truly reason, act, and judge.


You haven't created a writeup yet.

All submissions are due by Apr 16, 2026 at 7:59 PM EDT.
Overview
Latest update: Please ensure your submission includes a writeup that adheres to the format we provided AND an attached Kaggle Benchmark (it should look like this https://www.kaggle.com/benchmarks/<your username>/<your-benchmark-name>)

Current AI models often succeed by exploiting familiar data or memorized patterns, making existing evaluations poor judges of how models truly think. This hackathon challenges you to bridge that gap. Your task is to create high-quality benchmarks with Kaggle’s Benchmarks to test true understanding. We are asking you to focus on the cognitive faculties highlighted in Google DeepMind’s paper— Measuring progress toward AGI: A cognitive framework. The five faculties and tracks to focus on are: learning, metacognition, attention, executive functions, and social cognition. Designing these rigorous standards will build detailed cognitive profiles of frontier models and reveal exactly how close we are to achieving Artificial General Intelligence (AGI).

Start

a month ago
Close

10 hours to go
Description
Imagine a student who gets an A+ on a history test not because they understand the underlying events, but because they memorized the textbook. Current AI models can be similar: they display remarkable flashes of brilliance and crystallized knowledge, but often rely on surface-level patterns rather than fluid intelligence. This makes it difficult to distinguish when a model is truly solving a novel problem versus when it is simply recalling a scenario it has seen in its training data.

The core problem is that we lack an empirical framework to measure these limitations. We need evaluations that isolate specific cognitive abilities, resist shortcut solutions, and expose systematic failure modes. Without such benchmarks, progress toward human-level generality becomes difficult to interpret, comparisons between models become noisy, and important weaknesses remain hidden until deployment.

To move the field forward, we must look into the core cognitive faculties—the internal gears that determine how a system learns, monitors its own logic, and navigates nuance.

In this competition, hosted by Google DeepMind and Kaggle, we are inviting the Kaggle community to help solve this by building high-quality benchmarks designed to dig deeper than standard evaluations. Your goal is to create a Kaggle benchmark (with underlying tasks) using datasets that isolate specific cognitive abilities across five critical tracks: learning, metacognition, attention, executive functions, and social cognition. Using the new Kaggle Benchmarks platform, you will help the industry move away from broad, static scores and toward generating detailed cognitive profiles for frontier models.

A successful submission should answer a simple question: “What can this benchmark tell us about model behavior that we could not see before?”

This is your opportunity to contribute to the fast-growing field of AI research. By crowdsourcing novel benchmark ideas from researchers, practitioners, and domain experts, this hackathon aims to transform Artificial General Intelligence (AGI) from a subject of speculation into a grounded, measurable scientific endeavor.

If you have feedback on the Benchmarks product, please document it on this discussion forum thread, or join this Discord channel

Timeline
March 17, 2026 - Start Date.
April 16, 2026 - Final Submission Deadline.
April 17 - May 31, 2026 - Judging Period*
June 1, 2026 - Anticipated Results Announcement.
*Note - Judging period subject to change based on the number of submissions received

All deadlines are at 11:59 PM UTC on the corresponding day unless otherwise noted. The competition organizers reserve the right to update the contest timeline if they deem it necessary.

Submission Requirements
Note: Upon joining this hackathon, your Kaggle account will be provisioned with extra quota ($50/day, $500/month) to run the AI models for your benchmark. Read the Rules section 3.4.b to learn more.

A valid submission must contain the following:

Kaggle Writeup
[Mandatory] Kaggle Benchmark, as an attachment > “project links” > “Benchmark”
[Optional] Media Gallery
[Optional] Attached Public Notebook
Your final Submission must be made prior to the deadline. Any un-submitted or draft Writeups by the competition deadline will not be considered by the Judges.

To create a new Writeup, click on the "New Writeup" button here. After you have saved your Writeup, you should see a "Submit" button in the top right corner.

Note: If you attach a private Kaggle Resource to your public Kaggle Writeup, your private Resource will automatically be made public after the deadline.

1. Kaggle Writeup
The Kaggle Writeup serves as your project report. This should include a title, subtitle, and a detailed analysis of your submission. You must select a Track for your Writeup in order to submit.

Your Writeup should not exceed 1,500 words. Submissions over this limit may be subject to penalty.

The below assets must be attached to the Writeup to be eligible.

a. Kaggle Benchmark [mandatory]
This is the most important part of your writeup submission. You must create a Kaggle Benchmark with underlying tasks — all of which should be authored by you — and link the benchmark in the writeup as a project link (see section D below for more details). The tasks and benchmark should all be set to private. After the submission deadline, all tasks and benchmarks are published publicly.

Kaggle Benchmarks is a product that lets you – the Kaggle community – build, run, and share your own custom benchmarks for evaluating AI models at no cost.

Powered by the kaggle-benchmarks SDK, you can now create your own AI evaluations (“tasks”) and put them together into a collection (“benchmark”).

For more helpful resources, see:

- Kaggle Benchmarks guide

- Getting started notebook

- YouTube tutorial

- Kaggle-benchmarks open source GitHub Repo & DeepWiki

- Benchmarks cookbook: Guide to advanced features and use cases

- Example tasks: Get inspired with a variety of pre-built tasks

b. Media Gallery [optional]
This is where you should attach any images and/or videos associated with your submission. A cover image is required to submit your Writeup.

c. Public Notebook [optional]
Your code should be submitted as a public notebook in the Project Files field. Your notebook should be publicly accessible and not require a login or paywall. If you use a private Kaggle Notebook, it will automatically be made public after the deadline.

d. Public Project Link [mandatory]
A URL to your benchmark. This allows judges to analyze your project firsthand. Under the section “Attachments”, click on “Add a link”. This will open a panel on the right, where you will be able to select your benchmark and add it to the project.

Evaluation
Minimum requirements
Target one primary domain (to keep the signal sharp),
Clearly state which capability is being isolated, and
Explain what new insight the benchmark reveals about model behavior within that domain.
Evaluation
Submissions are evaluated on the following criteria:

Criteria (Percentage)	Description
Dataset quality & task construction
(50%)	Is the data defensible?
- Verifiably correct answers (no ambiguity)
- Sufficient sample size to be statistically significant

Are the tasks and benchmark built well?
- Clean, readable code
- Input prompt and output verification are robust.
Writeup quality
(20%)	Can the community use and learn from this? High quality writeups covering:
- Problem Statement: Which domains are you trying to solve and why
- Task & benchmark construction: How you’ve structured the code for the actual tasks and benchmark
- Dataset: its provenance, columns, and data types
- Technical details: Any additional details on how you implemented the benchmark or techniques
- Results, insights, and conclusions: How did the LLMs perform and what unique insights did you learn
- Organizational affiliations: Which organizations you might be affiliated with
- References & citations: Cite relevant work or papers that are similar or relevant to your submission.
Novelty, insights, and discriminatory power
(30%)	What can this benchmark tell us about model behavior that we could not see before?

Does the benchmark provide a meaningful signal?

We are looking for a gradient of performance. Can the benchmark significantly distinguish model performance?

A benchmark where everyone scores 0% is as useless as one where everyone scores 100%.
Proposed Writeup template
Use the following structure and in 3 pages or less present your work.

### Project Name

### Your Team

### Problem Statement

### Task & benchmark construction

### Dataset

### Technical details 

### Results, insights, and conclusions

### Organizational affiliations

### References & citations
Note: If you attach a private Kaggle Resource to your public Kaggle Writeup, your private Resource will automatically be made public after the deadline.

Grand Prizes
There will be four (4) $25,000 grand prizes to the best submissions across all tracks. In addition to these grand prizes, we also have 10 track prizes explained below (no repeat winners, for a total of 14 unique winners)

Tracks and Awards
Learning · $20,000
Can the model acquire and apply new knowledge and skills — not just recall what it was trained on?

Learning is the ability to acquire new knowledge or skills through experience. It is fundamental to adaptive intelligence: a system that cannot learn from new experiences is inherently brittle.

Current benchmarks test what models know (crystallized knowledge) rather than their capacity to learn on the fly. This track asks participants to create evaluations that isolate learning processes — including, reinforcement-based learning, concept formation, and skill learning.

Example evaluation targets:

Can the model learn a new rule or concept from a handful of examples and generalize it correctly?
Does the model retain information provided earlier in a long interaction, or does it drift and hallucinate?
Can the model update its beliefs when given corrective feedback, or does it perseverate on initial answers?
Track Awards

Winner (1 of 2)
$10,000

Winner (2 of 2)
$10,000
Metacognition · $20,000
Does the model know what it knows — and what it doesn't?

Metacognition is a system's knowledge about its own cognitive processes and its ability to monitor and control them. It is often under-evaluated in AI: we rarely test whether models can accurately judge their own confidence, detect errors, or adjust strategies when failing.

This track asks participants to build evaluations that probe metacognitive knowledge, monitoring, and control. Can the model understand its limitations, calibrate confidence, and adjust its behavior—for instance, by asking for clarification instead of guessing?

Example evaluation targets:

Is the model's stated confidence well-calibrated with its actual accuracy?
Can the model identify which questions it is likely to get wrong before answering?
When the model makes an error, does it detect and correct it — or does it confabulate a justification?
Does the model know the boundaries of its own knowledge (e.g., distinguishing "I know this" from "I'm guessing")?
Track Awards

Winner (1 of 2)
$10,000

Winner (2 of 2)
$10,000
Attention · $20,000
Can the model focus on what matters and ignore what doesn't?

Attention balances goal-relevant focus with responsiveness and is the ability to focus cognitive resources on specific aspects of perceptual stimuli, information, or task demands. In AI, failures appear as distraction by irrelevant context or missing critical details.

While sharing a name with the transformer mechanism, cognitive attention specifically refers to how a system allocates processing resources across competing information.

This track probes selective attention (filtering), sustained attention, and attention shifting (flexibility).

Example evaluation targets:

Does the model get distracted by irrelevant but salient information inserted into a prompt?
Does performance degrade systematically as input length increases, even when the task difficulty is held constant?
Can the model shift focus between sub-tasks in a complex, multi-part prompt without losing track?
How does the model perform when critical information is buried among large amounts of irrelevant context?
Track Awards

Winner (1 of 2)
$10,000

Winner (2 of 2)
$10,000
Executive Functions · $20,000
Can the model plan, inhibit impulses, and adapt flexibly — or does it default to habitual responses?

Executive functions include planning, inhibitory control, and cognitive flexibility. These are often conflated with "reasoning," but are distinct: a model may excel at logic yet struggle with multi-step plans or overriding habitual responses. This track asks for evaluations that isolate these processes to reveal a model's true ability to orchestrate complex thoughts and actions.

Example evaluation targets:

Can the model formulate and execute a multi-step plan, adjusting when intermediate steps fail?
When a habitual response pattern is wrong in a new context, can the model override it?
Can the model switch between different task rules or frameworks without perseverative errors?
How does the model handle situations where multiple plausible actions conflict with each other?
Can the model perform intermediate computations or mental manipulations without losing track (working memory)?
Track Awards

Winner (1 of 2)
$10,000

Winner (2 of 2)
$10,000
Social Cognition · $20,000
Can the model understand and navigate social situations — not just produce polite text?

Social cognition is the ability to interpret and respond to social information. For AI, it underpins inferring user intent, predicting reactions, and navigating competing perspectives. This track asks for evaluations that probe genuine social abilities beyond surface-level politeness.

Example evaluation targets:

Can the model infer a speaker's intention when it diverges from their literal statement?
Can the model track and reason about multiple agents with different (and possibly false) beliefs?
Does the model adjust its communication style appropriately for different social contexts and audiences?
Can the model navigate a negotiation scenario where goals are partially misaligned?
Does the model recognize and respond appropriately to implicit social norms?
Track Awards

Winner (1 of 2)
$10,000

Winner (2 of 2)
$10,000
Judges
Yibin Lin
Software Engineer, Kaggle
Prathamesh Bang
jhtschultz
Marc Coram
Yao Yan
MartynaPlomecka
Research Scientist, Google Deepmind
inversion
Data Scientist, Kaggle
Nicholas Kang
Product Manager, Kaggle
Long Phan
Lionel Levine
nicholashcain
yczhuang-gdm
Xin Liu
Kiran Vodrahalli
Isabelle
Oran Kelly
Citation
Martyna Plomecka, Yao Yan, Nicholas Kang, Ryan Burnell, María Cruz, and Sara Wolley. Measuring Progress Toward AGI - Cognitive Abilities. https://kaggle.com/competitions/kaggle-measuring-agi, 2026. Kaggle.


Cite
Competition Host
Google DeepMind

Prizes & Awards
$200,000

Does not award Points or Medals

Participation
7,614 Entrants

821 Participants

755 Teams

756 Submissions

Tags
Personal Benchmark
Benchmark
Research
Table of Contents
Skip to
content
Kaggle

Create
Home

Competitions

Datasets

Models

Benchmarks

Game Arena

Code

Discussions

Learn

More

Your Work


Viewed

Measuring Progress Toward AGI - Cognitive Abilities


New Benchmark Task 792c0


IgnoranceForge


Important submission info: please read before you submit


The Gemma 4 Good Hackathon


Edited

New Benchmark Task 792c0


IgnoranceForge


notebook91a9c96e49


notebook551e1df6fb


Graph2Proof


View Active Events

Search

Kaggle uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.
Learn more
OK, Got it.
Google DeepMind · Featured Hackathon · 10 hours to go

View Writeups
Measuring Progress Toward AGI - Cognitive Abilities
Design high-quality benchmarks that go beyond recall to evaluate how frontier models truly reason, act, and judge.


You haven't created a writeup yet.

All submissions are due by Apr 16, 2026 at 7:59 PM EDT.
Writeups

New Writeup

Tracks
Your Work

No writeups yet
Ready to share your project's story? Create a writeup to get started.

All
Cross-Modal Binding
Sample Project
Cross-Modal Binding
text -> image -> image -> text

Bob Fraser

Profile picture for Bob Fraser

Submitted
Project submitted
Viewable at Hackathon close

Team 1

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 2

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 3

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 4

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 5

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 6

Profile picture for Kaggler
Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 7

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 8

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 9

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 10

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 11

Profile picture for Kaggler
Profile picture for Kaggler
Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 12

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 13

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 14

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 15

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 16

Profile picture for Kaggler
Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 17

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 18

Profile picture for Kaggler

Submitted
Project submitted
Viewable at Hackathon close

Team 19

Profile picture for Kaggler
Skip to
content
Kaggle

Create
Home

Competitions

Datasets

Models

Benchmarks

Game Arena

Code

Discussions

Learn

More

Your Work


Viewed

Measuring Progress Toward AGI - Cognitive Abilities


New Benchmark Task 792c0


IgnoranceForge


Important submission info: please read before you submit


The Gemma 4 Good Hackathon


Edited

New Benchmark Task 792c0


IgnoranceForge


notebook91a9c96e49


notebook551e1df6fb


Graph2Proof


View Active Events

Search

Kaggle uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.
Learn more
OK, Got it.
Google DeepMind · Featured Hackathon · 10 hours to go

View Writeups
Measuring Progress Toward AGI - Cognitive Abilities
Design high-quality benchmarks that go beyond recall to evaluate how frontier models truly reason, act, and judge.


You haven't created a writeup yet.

All submissions are due by Apr 16, 2026 at 7:59 PM EDT.
Dataset Description
Welcome!

This is a Hackathon with no provided dataset.

Kaggle Benchmarks is a product that lets you – the Kaggle community – build, run, and share your own custom benchmarks for evaluating AI models at no cost.

Powered by the kaggle-benchmarks SDK, you can now create your own AI evaluations (“tasks”) and put them together into a collection (“benchmark”).

For more helpful resources, see:

Benchmarks launch announcement
Kaggle Benchmarks guide
Getting started notebook
YouTube tutorial
Kaggle-benchmarks open source GitHub Repo
Benchmarks cookbook: Guide to advanced features and use cases
Example tasks: Get inspired with a variety of pre-built tasks
Kaggle Benchmarks NotebookLM
Files
1 files

Size
144 B

Type
md

License
Apache 2.0

NOTE.md(144 B)
Welcome!

This is a Hackathon with no provided dataset.

Please refer to kaggle.com/competitions/kaggle-measuring-agi/data for data inspiration.

Data Explorer
144 B

NOTE.md

Summary
1 file


Download All
kaggle competitions download -c kaggle-measuring-agi
Download using Kaggle CLI

kagglehub.competition_download('kaggle-measuring-agi')
kagglehub

Prompt your client to use the "mcp_kaggle_download_competition_data_files" tool.
MCP

Metadata
License
Apache 2.0
Skip to
content
Kaggle

Create
Home

Competitions

Datasets

Models

Benchmarks

Game Arena

Code

Discussions

Learn

More

Your Work


Viewed

Measuring Progress Toward AGI - Cognitive Abilities


New Benchmark Task 792c0


IgnoranceForge


Important submission info: please read before you submit


The Gemma 4 Good Hackathon


Edited

New Benchmark Task 792c0


IgnoranceForge


notebook91a9c96e49


notebook551e1df6fb


Graph2Proof


View Active Events

Search

Kaggle uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.
Learn more
OK, Got it.
Google DeepMind · Featured Hackathon · 10 hours to go

View Writeups
Measuring Progress Toward AGI - Cognitive Abilities
Design high-quality benchmarks that go beyond recall to evaluate how frontier models truly reason, act, and judge.


You haven't created a writeup yet.

All submissions are due by Apr 16, 2026 at 7:59 PM EDT.
You have accepted the rules for this competition. Good luck!
Competition Rules
ENTRY IN THIS COMPETITION CONSTITUTES YOUR ACCEPTANCE OF THESE OFFICIAL COMPETITION RULES.
See Section 3.18 for defined terms

The Competition named below is a skills-based competition to promote and further the field of data science. You must register via the Competition Website to enter. To enter the Competition, you must agree to these Official Competition Rules, which incorporate by reference the provisions and content of the Competition Website and any Specific Competition Rules herein (collectively, the "Rules"). Please read these Rules carefully before entry to ensure you understand and agree. You further agree that Submission in the Competition constitutes agreement to these Rules. You may not submit to the Competition and are not eligible to receive the prizes associated with this Competition unless you agree to these Rules. These Rules form a binding legal agreement between you and the Competition Sponsor with respect to the Competition. Your competition Submissions must conform to the requirements stated on the Competition Website. Your Submissions will be scored based on the evaluation metric described on the Competition Website. Subject to compliance with the Competition Rules, Prizes, if any, will be awarded to Participants with the best scores, based on the merits of the data science models submitted. See below for the complete Competition Rules. For Competitions designated as hackathons by the Competition Sponsor (“Hackathons”), your Submissions will be judged by the Competition Sponsor based on the evaluation rubric set forth on the Competition Website (“Evaluation Rubric”). The Prizes, if any, will be awarded to Participants with the highest ranking(s) as determined by the Competition Sponsor based on such rubric.

You cannot sign up to Kaggle from multiple accounts and therefore you cannot enter or submit from multiple accounts.

1. COMPETITION-SPECIFIC TERMS
1. COMPETITION TITLE
Measuring AGI - Cognition and Values

2. COMPETITION SPONSOR
Google LLC

3. COMPETITION SPONSOR ADDRESS
1600 Amphitheatre Parkway, Mountain View, California 94043 USA

4. COMPETITION WEBSITE
https://www.kaggle.com/competitions/kaggle-measuring-agi

5. TOTAL PRIZES AVAILABLE: $200,000
There will be four (4) $25,000 grand prizes to the best submissions across all tracks. In addition to these grand prizes, we also have 10 track prizes explained below (no repeat winners, for a total of 14 unique winners)

Track # 1: Learning: two (2) awards for a total of $10,000 each
Track #2: Metacognition: two (2) awards for a total of $10,000 each
Track #3: Attention: two (2) awards for a total of $10,000 each
Track #4: Executive function: two (2) awards for a total of $10,000 each
Track #5: Social cognition: two (2) awards for a total of $10,000 each
6. WINNER LICENSE TYPE
CC0

7. DATA ACCESS AND USE
The Benchmarks SDK is under an Apache 2.0 license.

2. COMPETITION-SPECIFIC RULES
In addition to the provisions of the General Competition Rules below, you understand and agree to these Competition-Specific Rules required by the Competition Sponsor:

1. TEAM LIMITS
a. The maximum Team size is five (5). b. Team mergers are allowed and can be performed by the Team leader. In order to merge, the combined Team must have a total Submission count less than or equal to the maximum allowed as of the Team Merger Deadline. The maximum allowed is the number of Submissions per day multiplied by the number of days the competition has been running. For Hackathons, each team is allowed one (1) Submission; any Submissions submitted by Participants before merging into a Team will be unsubmitted.

2. SUBMISSION LIMITS
a. For Hackathons, each Team may submit one (1) Submission only.

3. COMPETITION TIMELINE
a. Competition Timeline dates (including Entry Deadline, Final Submission Deadline, Start Date, and Team Merger Deadline, as applicable) are reflected on the competition’s Overview > Timeline page.

4. COMPETITION DATA
a. Data Access and Use.

None. Competition Data will not be provided by Competition Sponsor for this Competition.
b. Data Security.

You agree to use reasonable and suitable measures to prevent persons who have not formally agreed to these Rules from gaining access to the Competition Data. You agree not to transmit, duplicate, publish, redistribute or otherwise provide or make available the Competition Data to any party not participating in the Competition. You agree to notify Kaggle immediately upon learning of any possible unauthorized transmission of or unauthorized access to the Competition Data and agree to work with Kaggle to rectify any unauthorized transmission or access.
5. WINNER LICENSE
a. Under Section 2.8 (Winners Obligations) of the General Rules below, you hereby grant and will grant the Competition Sponsor the following license(s) with respect to your Submission if you are a Competition winner:

Open Source: You hereby license and will license your winning Submission and the source code used to generate the Submission under CC0, an Open Source Initiative-approved license (see www.opensource.org) that in no event limits commercial use of such code or model containing or depending on such code.

For generally commercially available software that you used to generate your Submission that is not owned by you, but that can be procured by the Competition Sponsor without undue expense, you do not need to grant the license in the preceding Section for that software.

In the event that input data or pretrained models with an incompatible license are used to generate your winning solution, you do not need to grant an open source license in the preceding Section for that data and/or model(s).

b. You may be required by the Sponsor to provide a detailed description of how the winning Submission was generated, to the Competition Sponsor’s specifications, as outlined in Section 2.8, Winner’s Obligations. This may include a detailed description of methodology, where one must be able to reproduce the approach by reading the description, and includes a detailed explanation of the architecture, preprocessing, loss function, training details, hyper-parameters, etc. The description should also include a link to a code repository with complete and detailed instructions so that the results obtained can be reproduced.

6. EXTERNAL DATA AND TOOLS
a. You may use data other than the Competition Data (“External Data”) to develop and test your Submissions. However, you will ensure the External Data is either publicly available and equally accessible to use by all Participants of the Competition for purposes of the competition at no cost to the other Participants, or satisfies the Reasonableness criteria as outlined in Section 2.6.b below. The ability to use External Data under this Section does not limit your other obligations under these Competition Rules, including but not limited to Section 2.8 (Winners Obligations).

b. The use of external data and models is acceptable unless specifically prohibited by the Host. Because of the potential costs or restrictions (e.g., “geo restrictions”) associated with obtaining rights to use external data or certain software and associated tools, their use must be “reasonably accessible to all” and of “minimal cost”. Also, regardless of the cost challenges as they might affect all Participants during the course of the competition, the costs of potentially procuring a license for software used to generate a Submission, must also be considered. The Host will employ an assessment of whether or not the following criteria can exclude the use of the particular LLM, data set(s), or tool(s):

Are Participants being excluded from a competition because of the "excessive" costs for access to certain LLMs, external data, or tools that might be used by other Participants. The Host will assess the excessive cost concern by applying a “Reasonableness” standard (the “Reasonableness Standard”). The Reasonableness Standard will be determined and applied by the Host in light of things like cost thresholds and accessibility.

By way of example only, a small subscription charge to use additional elements of a large language model such as Gemini Advanced are acceptable if meeting the Reasonableness Standard of Sec. 8.2. Purchasing a license to use a proprietary dataset that exceeds the cost of a prize in the competition would not be considered reasonable.

c. Automated Machine Learning Tools (“AMLT”)

Individual Participants and Teams may use automated machine learning tool(s) (“AMLT”) (e.g., Google toML, H2O Driverless AI, etc.) to create a Submission, provided that the Participant or Team ensures that they have an appropriate license to the AMLT such that they are able to comply with the Competition Rules.
7. ELIGIBILITY
a. Unless otherwise stated in the Competition-Specific Rules above or prohibited by internal policies of the Competition Entities, employees, interns, contractors, officers and directors of Competition Entities may enter and participate in the Competition, but are not eligible to win any Prizes. "Competition Entities" means the Competition Sponsor, Kaggle Inc., and their respective parent companies, subsidiaries and affiliates. If you are such a Participant from a Competition Entity, you are subject to all applicable internal policies of your employer with respect to your participation.

8. WINNER’S OBLIGATIONS
a. As a condition to being awarded a Prize, a Prize winner must fulfill the following obligations:

Deliver to the Competition Sponsor the final model's software code as used to generate the winning Submission and associated documentation. The delivered software code should follow these documentation guidelines, must be capable of generating the winning Submission, and contain a description of resources required to build and/or run the executable code successfully. For avoidance of doubt, delivered software code should include training code, inference code, and a description of the required computational environment. For Hackathons, the Submission deliverables will be as described on the Competition Website, which may be information or materials that are not software code.
a. To the extent that the final model’s software code includes generally commercially available software that is not owned by you, but that can be procured by the Competition Sponsor without undue expense, then instead of delivering the code for that software to the Competition Sponsor, you must identify that software, method for procuring it, and any parameters or other information necessary to replicate the winning Submission; Individual Participants and Teams who create a Submission using an AMLT may win a Prize. However, for clarity, the potential winner’s Submission must still meet the requirements of these Rules, including but not limited to Section 2.5 (Winners License), Section 2.8 (Winners Obligations), and Section 3.14 (Warranty, Indemnity, and Release).”

b. Individual Participants and Teams who create a Submission using an AMLT may win a Prize. However, for clarity, the potential winner’s Submission must still meet the requirements of these Rules,

Grant to the Competition Sponsor the license to the winning Submission stated in the Competition Specific Rules above, and represent that you have the unrestricted right to grant that license;

Sign and return all Prize acceptance documents as may be required by Competition Sponsor or Kaggle, including without limitation: (a) eligibility certifications; (b) licenses, releases and other agreements required under the Rules; and (c) U.S. tax forms (such as IRS Form W-9 if U.S. resident, IRS Form W-8BEN if foreign resident, or future equivalents).

9. GOVERNING LAW
a. Unless otherwise provided in the Competition Specific Rules above, all claims arising out of or relating to these Rules will be governed by California law, excluding its conflict of laws rules, and will be litigated exclusively in the Federal or State courts of Santa Clara County, California, USA. The parties consent to personal jurisdiction in those courts. If any provision of these Rules is held to be invalid or unenforceable, all remaining provisions of the Rules will remain in full force and effect.

3. GENERAL COMPETITION RULES - BINDING AGREEMENT
1. ELIGIBILITY
a. To be eligible to enter the Competition, you must be:

a registered account holder at Kaggle.com;
the older of 18 years old or the age of majority in your jurisdiction of residence (unless otherwise agreed to by Competition Sponsor and appropriate parental/guardian consents have been obtained by Competition Sponsor);
not a resident of Crimea, so-called Donetsk People's Republic (DNR) or Luhansk People's Republic (LNR), Cuba, Iran, Syria, or North Korea; and
not a person or representative of an entity under U.S. export controls or sanctions (see: https://www.treasury.gov/resourcecenter/sanctions/Programs/Pages/Programs.aspx).
b. Competitions are open to residents of the United States and worldwide, except that if you are a resident of Crimea, so-called Donetsk People's Republic (DNR) or Luhansk People's Republic (LNR), Cuba, Iran, Syria, North Korea, or are subject to U.S. export controls or sanctions, you may not enter the Competition. Other local rules and regulations may apply to you, so please check your local laws to ensure that you are eligible to participate in skills-based competitions. The Competition Host reserves the right to forego or award alternative Prizes where needed to comply with local laws. If a winner is located in a country where prizes cannot be awarded, then they are not eligible to receive a prize.

c. If you are entering as a representative of a company, educational institution or other legal entity, or on behalf of your employer, these rules are binding on you, individually, and the entity you represent or where you are an employee. If you are acting within the scope of your employment, or as an agent of another party, you warrant that such party or your employer has full knowledge of your actions and has consented thereto, including your potential receipt of a Prize. You further warrant that your actions do not violate your employer's or entity's policies and procedures.

d. The Competition Sponsor reserves the right to verify eligibility and to adjudicate on any dispute at any time. If you provide any false information relating to the Competition concerning your identity, residency, mailing address, telephone number, email address, ownership of right, or information required for entering the Competition, you may be immediately disqualified from the Competition.

2. SPONSOR AND HOSTING PLATFORM
a. The Competition is sponsored by Competition Sponsor named above. The Competition is hosted on behalf of Competition Sponsor by Kaggle Inc. ("Kaggle"). Kaggle is an independent contractor of Competition Sponsor, and is not a party to this or any agreement between you and Competition Sponsor. You understand that Kaggle has no responsibility with respect to selecting the potential Competition winner(s) or awarding any Prizes. Kaggle will perform certain administrative functions relating to hosting the Competition, and you agree to abide by the provisions relating to Kaggle under these Rules. As a Kaggle.com account holder and user of the Kaggle competition platform, remember you have accepted and are subject to the Kaggle Terms of Service at www.kaggle.com/terms in addition to these Rules.

3. COMPETITION PERIOD
a. For the purposes of Prizes, the Competition will run from the Start Date and time to the Final Submission Deadline (such duration the “Competition Period”). The Competition Timeline is subject to change, and Competition Sponsor may introduce additional hurdle deadlines during the Competition Period. Any updated or additional deadlines will be publicized on the Competition Website. It is your responsibility to check the Competition Website regularly to stay informed of any deadline changes. YOU ARE RESPONSIBLE FOR DETERMINING THE CORRESPONDING TIME ZONE IN YOUR LOCATION.

4. COMPETITION ENTRY
a. NO PURCHASE NECESSARY TO ENTER OR WIN. To enter the Competition, you must register on the Competition Website prior to the Entry Deadline, and follow the instructions for developing and entering your Submission through the Competition Website. Your Submissions must be made in the manner and format, and in compliance with all other requirements, stated on the Competition Website (the "Requirements"). Submissions must be received before any Submission deadlines stated on the Competition Website. Submissions not received by the stated deadlines will not be eligible to receive a Prize.

b. Upon joining the hackathon, your Kaggle account will be provisioned with extra quota ($50/day, $500/month) to run the AI models for your benchmark. If you run out, you can email kaggle-benchmarks-agi-hackathon@google.com with your request

c. By making a submission, you declare that everything you submitted is true to your knowledge.

d. Except as expressly allowed in Hackathons as set forth on the Competition Website, submissions may not use or incorporate information from hand labeling or human prediction of the validation dataset or test data records.

e. If the Competition is a multi-stage competition with temporally separate training and/or test data, one or more valid Submissions may be required during each Competition stage in the manner described on the Competition Website in order for the Submissions to be Prize eligible.

f. Submissions are void if they are in whole or part illegible, incomplete, damaged, altered, counterfeit, obtained through fraud, or late. Competition Sponsor reserves the right to disqualify any entrant who does not follow these Rules, including making a Submission that does not meet the Requirements.

5. INDIVIDUALS AND TEAMS
a. Individual Account. You may make Submissions only under one, unique Kaggle.com account. You will be disqualified if you make Submissions through more than one Kaggle account, or attempt to falsify an account to act as your proxy. You may submit up to the maximum number of Submissions per day as specified on the Competition Website.

b. Teams. If permitted under the Competition Website guidelines, multiple individuals may collaborate as a Team; however, you may join or form only one Team. Each Team member must be a single individual with a separate Kaggle account. You must register individually for the Competition before joining a Team. You must confirm your Team membership to make it official by responding to the Team notification message sent to your Kaggle account. Team membership may not exceed the Maximum Team Size stated on the Competition Website.

c. Team Merger. Teams (or individual Participants) may request to merge via the Competition Website. Team mergers may be allowed provided that: (i) the combined Team does not exceed the Maximum Team Size; (ii) the number of Submissions made by the merging Teams does not exceed the number of Submissions permissible for one Team at the date of the merger request; (iii) the merger is completed before the earlier of: any merger deadline or the Competition deadline; and (iv) the proposed combined Team otherwise meets all the requirements of these Rules.

d. Private Sharing. No private sharing outside of Teams. Privately sharing code or data outside of Teams is not permitted. It's okay to share code if made available to all Participants on the forums.

6. SUBMISSION CODE REQUIREMENTS
a. Private Code Sharing. Unless otherwise specifically permitted under the Competition Website or Competition Specific Rules above, during the Competition Period, you are not allowed to privately share source or executable code developed in connection with or based upon the Competition Data or other source or executable code relevant to the Competition (“Competition Code”). This prohibition includes sharing Competition Code between separate Teams, unless a Team merger occurs. Any such sharing of Competition Code is a breach of these Competition Rules and may result in disqualification.

b. Public Code Sharing. You are permitted to publicly share Competition Code, provided that such public sharing does not violate the intellectual property rights of any third party. If you do choose to share Competition Code or other such code, you are required to share it on Kaggle.com on the discussion forum or notebooks associated specifically with the Competition for the benefit of all competitors. By so sharing, you are deemed to have licensed the shared code under an Open Source Initiative-approved license (see www.opensource.org) that in no event limits commercial use of such Competition Code or model containing or depending on such Competition Code.

c. Use of Open Source. Unless otherwise stated in the Specific Competition Rules above, if open source code is used in the model to generate the Submission, then you must only use open source code licensed under an Open Source Initiative-approved license (see www.opensource.org) that in no event limits commercial use of such code or model containing or depending on such code.

7. DETERMINING WINNERS
a. Each Submission will be scored and/or ranked by the evaluation metric, or Evaluation Rubric (in the case of Hackathon Competitions),stated on the Competition Website. During the Competition Period, the current ranking will be visible on the Competition Website's Public Leaderboard. The potential winner(s) are determined solely by the leaderboard ranking on the Private Leaderboard, subject to compliance with these Rules. The Public Leaderboard will be based on the public test set and the Private Leaderboard will be based on the private test set. There will be no leaderboards for Hackathon Competitions. b. In the event of a tie, the Submission that was entered first to the Competition will be the winner. In the event a potential winner is disqualified for any reason, the Submission that received the next highest score rank will be chosen as the potential winner. For Hackathon Competitions, each of the top Submissions will get a unique ranking and there will be no tiebreakers.

8. NOTIFICATION OF WINNERS & DISQUALIFICATION
a. The potential winner(s) will be notified by email.

b. If a potential winner (i) does not respond to the notification attempt within one (1) week from the first notification attempt or (ii) notifies Kaggle within one week after the Final Submission Deadline that the potential winner does not want to be nominated as a winner or does not want to receive a Prize, then, in each case (i) and (ii) such potential winner will not receive any Prize, and an alternate potential winner will be selected from among all eligible entries received based on the Competition’s judging criteria.

c. In case (i) and (ii) above Kaggle may disqualify the Participant. However, in case (ii) above, if requested by Kaggle, such potential winner may provide code and documentation to verify the Participant’s compliance with these Rules. If the potential winner provides code and documentation to the satisfaction of Kaggle, the Participant will not be disqualified pursuant to this paragraph.

d. Competition Sponsor reserves the right to disqualify any Participant from the Competition if the Competition Sponsor reasonably believes that the Participant has attempted to undermine the legitimate operation of the Competition by cheating, deception, or other unfair playing practices or abuses, threatens or harasses any other Participants, Competition Sponsor or Kaggle.

e. A disqualified Participant may be removed from the Competition leaderboard, at Kaggle's sole discretion. If a Participant is removed from the Competition Leaderboard, additional winning features associated with the Kaggle competition platform, for example Kaggle points or medals, may also not be awarded.

f. The final leaderboard list will be publicly displayed at Kaggle.com. Determinations of Competition Sponsor are final and binding.

9. PRIZES
a. Prize(s) are as described on the Competition Website and are only available for winning during the time period described on the Competition Website. The odds of winning any Prize depends on the number of eligible Submissions received during the Competition Period and the skill of the Participants. b. All Prizes are subject to Competition Sponsor's review and verification of the Participant’s eligibility and compliance with these Rules, and the compliance of the winning Submissions with the Submissions Requirements. In the event that the Submission demonstrates non-compliance with these Competition Rules, Competition Sponsor may at its discretion take either of the following actions: (i) disqualify the Submission(s); or (ii) require the potential winner to remediate within one week after notice all issues identified in the Submission(s) (including, without limitation, the resolution of license conflicts, the fulfillment of all obligations required by software licenses, and the removal of any software that violates the software restrictions). c. A potential winner may decline to be nominated as a Competition winner in accordance with Section 3.8. d. Potential winners must return all required Prize acceptance documents within two (2) weeks following notification of such required documents, or such potential winner will be deemed to have forfeited the prize and another potential winner will be selected. Prize(s) will be awarded within approximately thirty (30) days after receipt by Competition Sponsor or Kaggle of the required Prize acceptance documents. Transfer or assignment of a Prize is not allowed. e. You are not eligible to receive any Prize if you do not meet the Eligibility requirements in Section 2.7 and Section 3.1 above. f. If a Team wins a monetary Prize, the Prize money will be allocated in even shares between the eligible Team members, unless the Team unanimously opts for a different Prize split and notifies Kaggle before Prizes are issued.

10. TAXES
a. ALL TAXES IMPOSED ON PRIZES ARE THE SOLE RESPONSIBILITY OF THE WINNERS. Payments to potential winners are subject to the express requirement that they submit all documentation requested by Competition Sponsor or Kaggle for compliance with applicable state, federal, local and foreign (including provincial) tax reporting and withholding requirements. Prizes will be net of any taxes that Competition Sponsor is required by law to withhold. If a potential winner fails to provide any required documentation or comply with applicable laws, the Prize may be forfeited and Competition Sponsor may select an alternative potential winner. Any winners who are U.S. residents will receive an IRS Form-1099 in the amount of their Prize.

11. GENERAL CONDITIONS
a. All federal, state, provincial and local laws and regulations apply.

12. PUBLICITY
a. You agree that Competition Sponsor, Kaggle and its affiliates may use your name and likeness for advertising and promotional purposes without additional compensation, unless prohibited by law.

13. PRIVACY
a. You acknowledge and agree that Competition Sponsor and Kaggle may collect, store, share and otherwise use personally identifiable information provided by you during the Kaggle account registration process and the Competition, including but not limited to, name, mailing address, phone number, and email address (“Personal Information”). Kaggle acts as an independent controller with regard to its collection, storage, sharing, and other use of this Personal Information, and will use this Personal Information in accordance with its Privacy Policy <www.kaggle.com/privacy>, including for administering the Competition. As a Kaggle.com account holder, you have the right to request access to, review, rectification, portability or deletion of any personal data held by Kaggle about you by logging into your account and/or contacting Kaggle Support at <www.kaggle.com/contact>. b. As part of Competition Sponsor performing this contract between you and the Competition Sponsor, Kaggle will transfer your Personal Information to Competition Sponsor, which acts as an independent controller with regard to this Personal Information. As a controller of such Personal Information, Competition Sponsor agrees to comply with all U.S. and foreign data protection obligations with regard to your Personal Information. Kaggle will transfer your Personal Information to Competition Sponsor in the country specified in the Competition Sponsor Address listed above, which may be a country outside the country of your residence. Such country may not have privacy laws and regulations similar to those of the country of your residence.

14. WARRANTY, INDEMNITY AND RELEASE
a. You warrant that your Submission is your own original work and, as such, you are the sole and exclusive owner and rights holder of the Submission, and you have the right to make the Submission and grant all required licenses. You agree not to make any Submission that: (i) infringes any third party proprietary rights, intellectual property rights, industrial property rights, personal or moral rights or any other rights, including without limitation, copyright, trademark, patent, trade secret, privacy, publicity or confidentiality obligations, or defames any person; or (ii) otherwise violates any applicable U.S. or foreign state or federal law. b. To the maximum extent permitted by law, you indemnify and agree to keep indemnified Competition Entities at all times from and against any liability, claims, demands, losses, damages, costs and expenses resulting from any of your acts, defaults or omissions and/or a breach of any warranty set forth herein. To the maximum extent permitted by law, you agree to defend, indemnify and hold harmless the Competition Entities from and against any and all claims, actions, suits or proceedings, as well as any and all losses, liabilities, damages, costs and expenses (including reasonable attorneys fees) arising out of or accruing from: (a) your Submission or other material uploaded or otherwise provided by you that infringes any third party proprietary rights, intellectual property rights, industrial property rights, personal or moral rights or any other rights, including without limitation, copyright, trademark, patent, trade secret, privacy, publicity or confidentiality obligations, or defames any person; (b) any misrepresentation made by you in connection with the Competition; (c) any non-compliance by you with these Rules or any applicable U.S. or foreign state or federal law; (d) claims brought by persons or entities other than the parties to these Rules arising from or related to your involvement with the Competition; and (e) your acceptance, possession, misuse or use of any Prize, or your participation in the Competition and any Competition-related activity. c. You hereby release Competition Entities from any liability associated with: (a) any malfunction or other problem with the Competition Website; (b) any error in the collection, processing, or retention of any Submission; or (c) any typographical or other error in the printing, offering or announcement of any Prize or winners.

15. INTERNET
a. Competition Entities are not responsible for any malfunction of the Competition Website or any late, lost, damaged, misdirected, incomplete, illegible, undeliverable, or destroyed Submissions or entry materials due to system errors, failed, incomplete or garbled computer or other telecommunication transmission malfunctions, hardware or software failures of any kind, lost or unavailable network connections, typographical or system/human errors and failures, technical malfunction(s) of any telephone network or lines, cable connections, satellite transmissions, servers or providers, or computer equipment, traffic congestion on the Internet or at the Competition Website, or any combination thereof, which may limit a Participant’s ability to participate.

16. RIGHT TO CANCEL, MODIFY OR DISQUALIFY
a. If for any reason the Competition is not capable of running as planned, including infection by computer virus, bugs, tampering, unauthorized intervention, fraud, technical failures, or any other causes which corrupt or affect the administration, security, fairness, integrity, or proper conduct of the Competition, Competition Sponsor reserves the right to cancel, terminate, modify or suspend the Competition. Competition Sponsor further reserves the right to disqualify any Participant who tampers with the submission process or any other part of the Competition or Competition Website. Any attempt by a Participant to deliberately damage any website, including the Competition Website, or undermine the legitimate operation of the Competition is a violation of criminal and civil laws. Should such an attempt be made, Competition Sponsor and Kaggle each reserves the right to seek damages from any such Participant to the fullest extent of the applicable law.

17. NOT AN OFFER OR CONTRACT OF EMPLOYMENT
a. Under no circumstances will the entry of a Submission, the awarding of a Prize, or anything in these Rules be construed as an offer or contract of employment with Competition Sponsor or any of the Competition Entities. You acknowledge that you have submitted your Submission voluntarily and not in confidence or in trust. You acknowledge that no confidential, fiduciary, agency, employment or other similar relationship is created between you and Competition Sponsor or any of the Competition Entities by your acceptance of these Rules or your entry of your Submission.

18. DEFINITIONS
a. "Competition Data" are the data or datasets available from the Competition Website for the purpose of use in the Competition, including any prototype or executable code provided on the Competition Website. The Competition Data will contain private and public test sets. Which data belongs to which set will not be made available to Participants. b. An “Entry” is when a Participant has joined, signed up, or accepted the rules of a competition. Entry is required to make a Submission to a competition. c. A “Final Submission” is the Submission selected by the user, or automatically selected by Kaggle in the event not selected by the user, that is/are used for final placement on the competition leaderboard. d. A “Participant” or “Participant User” is an individual who participates in a competition by entering the competition and making a Submission. e. The “Private Leaderboard” is a ranked display of Participants’ Submission scores against the private test set. The Private Leaderboard determines the final standing in the competition. f. The “Public Leaderboard” is a ranked display of Participants’ Submission scores against a representative sample of the test data. This leaderboard is visible throughout the competition. g. A “Sponsor” is responsible for hosting the competition, which includes but is not limited to providing the data for the competition, determining winners, and enforcing competition rules. h. A “Submission” is anything provided by the Participant to the Sponsor to be evaluated for competition purposes and determine leaderboard position. A Submission may be made as a model, notebook, prediction file, or other format as determined by the Sponsor. i. A “Team” is one or more Participants participating together in a Kaggle competition, by officially merging together as a Team within the competition platform.

Rules
Skip to
content
Kaggle

Create
Home

Competitions

Datasets

Models

Benchmarks

Game Arena

Code

Discussions

Learn

More

Your Work


Viewed

Cross-Modal Binding


Measuring Progress Toward AGI - Cognitive Abilities


Cross modal association


Cross modal images


Metacognitive Calibration Benchmark


Edited

New Benchmark Task 792c0


IgnoranceForge


notebook91a9c96e49


notebook551e1df6fb


Graph2Proof


View Active Events

Skip to
content
Kaggle
Kaggle uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.
Learn more
OK, Got it.

Writeups
Cross-Modal Binding
text -> image -> image -> text


Measuring Progress Toward AGI - Cognitive Abilities

Hackathon Writeup · Feb 24, 2026


Project Name
Cross-Modal Binding

Your Team
Bob

Problem Statement
This benchmark evaluates an LLM's ability to perform Cross-Modal Binding—a specific sub-dimension of Working Memory (WM). As defined in Section E.4.1 of “A Definition of AGI” (Hendrycks et al., 2023), this tests whether a model can move beyond simple pattern recognition to functional reasoning within its "mental" workspace.

While many models can identify objects or read text, this task requires the model to maintain a relationship between a text label and a semantically distinct but categorically related object within a single visual context.

Task & benchmark construction
The benchmark utilizes a "Point-and-Identify" structure:

Input: An image containing multiple labeled objects and a text prompt specifying one of those labels.

Internal Logic: The model must locate the label in the image, identify the specific object the label is physically attached to, and determine that object's identity.

Output: A single-word response naming the entity associated with the label.

The code is structured to iterate through 10 distinct trials, passing the image and the target label to the model's vision API and comparing the string output to the ground truth.

Dataset
The dataset consists of 10 images that were generated using Nano Banana for the purposes of this benchmark. Since they are novel, these images did not exist in any model's training set.

The images are a mix of abstract, photorealistic, and illustrative styles to prevent style-specific bias.

All images are jpeg format.

Technical details
The benchmark implementation focuses on zero-shot robustness.

Prompting Strategy: Models are given a strict system instruction: "Return only the name of the object. No preamble, no explanation."
Scoring: A binary Exact Match (EM) metric is used. Since the task requires a single-word identifier, any verbosity (e.g., "The object is a cat") is penalized as a failure in instruction following, which is a key component of Working Memory performance. The final score is the fraction of correct responses produced by the model.
Iteration: The initial scaffolding was prototyped with Gemini, then manually refined to ensure the labels in the images were not "too easy" (e.g., ensuring labels weren't just the name of the object itself, but rather arbitrary identifiers).

Results, insights, and conclusions
This simple benchmark shows surprisingly high performance, but the failure modes were interesting. Models didn't fail on the same images, which suggests that failures may be due to spatial reasoning errors (misidentifying which object a label is "pointing" to) rather than a lack of object recognition.

Cross-modal association remains a "brittle" skill. Even models that perform well can be tripped up by stylistic shifts in the image, indicating that "Working Memory" in LLMs is still highly sensitive to visual noise.

Organizational affiliations
Kaggle, Google

References & citations
Hendrycks, D., Song, D., Szegedy, C., Lee, H., Gal, Y., Brynjolfsson, E., Li, S., Zou, A., Levine, L., Han, B., Fu, J., Liu, Z., Shin, J., Lee, K., Mazeika, M., Phan, L., Ingebretsen, G., Khoja, A., Xie, C., Salaudeen, O., Hein, M., Zhao, K., Pan, A., Duvenaud, D., Li, B., Omohundro, S., Alfour, G., Tegmark, M., McGrew, K., Marcus, G., Tallinn, J., Schmidt, E., & Bengio, Y. (2025). A Definition of AGI. arXiv. https://arxiv.org/abs/2510.18212

Author
Bob Fraser
bobfraserg


Share
Competition Prize Track
Attention
Project Links
Cross modal images
3 months ago · Usability 10.0


Kaggle Dataset

Public

Cross modal association
3 months ago · 7 upvotes

Kaggle Benchmark

Public

All private task notebooks your team created for tasks in this benchmark will be made public when the hackathon ends.
License
This Writeup has been released under the CC0: Public Domain license.

Citation
Bob Fraser. Cross-Modal Binding. https://www.kaggle.com/competitions/kaggle-measuring-agi/writeups/cross-modal-binding. 2026. Kaggle

